package com.ohgiraffers.test.run;

import com.ohgiraffers.test.view.BookMenu;


public class Application {

    public static void main(String[] args) {

        /* BookMenu 클래스 객체 생성하고 menu() 메서드 실행 */

        /* BookMenu 클래스 객체 생성 */
        BookMenu bookMenu = new BookMenu();

        /* menu() 메소드 실행 */
        bookMenu.menu();

    }



}
